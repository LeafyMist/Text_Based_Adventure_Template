#include <iostream>
#include <random>
#include "decision.cpp"
#include "help.cpp"
using namespace std;

string userText;
int gp;
string inventory[10];

// the 'input' method saves time writing out a frequently used expression.
extern void input() {
    cin >> userText;
    cout << endl;
}

int main() {
    inventory[0] = "_0ld_dat4_";
    inventory[9] = "";

    cout << endl << "As you open your eyes you find yourself atop a small hill, you are laying in the shade of a large white tree." << endl
    << "Looking past it's thick foliage you can see two paths through the plains." << endl
    << "One of these paths heads  * left *  towards a small village and the other goes  * right *  veering off towards an unkept mineshaft entrance. " << endl
    << endl << "Which direction would you like to go?" << endl;

    input();

    help();

    // create a variable that outputs the 'left'(town) and 'right'(mineshaft) dialogue options.
    // then, allow another decision section after the else statement.
    string townEntry = "enter village!";

    string mineEntry = "enter mine!";

    if (userText == "left") {
        cout << townEntry << endl;
    } else if (userText == "right") {
        cout << mineEntry << endl;
    } else {
        cout << "Select either 'left', 'right', or 'help' for now." << endl;
        input();
        help();
        if (userText == "left") {
            cout << townEntry << endl;
        } else if (userText == "right") {
            cout << mineEntry << endl;
        }
    }

    input();
    decision("Test", "Good Day, Planet", "", "", "", "", "", "");

    return 0;

}
