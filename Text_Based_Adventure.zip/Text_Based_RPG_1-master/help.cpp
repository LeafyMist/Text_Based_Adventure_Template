//
// Created by tomra on 11/04/2024.
//
#include <iostream>
using namespace std;

extern string userText;
extern int gp;
extern string inventory[10];


// defining the 'menu' methods for when a user asks for help (displaying a list of commands) or wants to access their inventory/gp.
static void help() {
    if (userText == "help") {
        cout << "Possible answers are displayed like  * this *  in text. They should be typed in lowercase as they are seen." << endl
             << "After asking for help (or entering a menu) you may immediately respond to the previous prompt." << endl << endl;
        cout << "Command List:" << endl
             << "Inventory = 'i'" << endl
             << "Check Gold Pieces = 'gp'" << endl;
        cin >> userText;
        cout << endl;

        if (userText == "i") {
            cout << "Your Inventory contains:" << endl;
            for (int i = 0; i < 10; i++)
                cout << inventory[i] << endl;
            cin >> userText;
            cout << endl;
        } else if (userText == "gp") {
            cout << "You have --- " << gp << " --- gold pieces" << endl;
            cin >> userText;
            cout << endl;
        }
    }
}