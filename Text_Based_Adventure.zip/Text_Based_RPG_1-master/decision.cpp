//
// Created by tomra on 23/03/2024.
//

#include <iostream>
using namespace std;

extern string userText;

// 'decision' method takes a string - d1 - and compares it to the inputted 'userText'.
// Then, if the two are the same, it will output a response - d1out - to continue the game
// and eventually prompt the user for another input.
// It is assumed that the number of decisions in the game will grow rapidly, this method is being created
// to hopefully reduce overall coding time.
// 'decision' instances may be converted to variables to be re-used (example: on entrance of village).

static void decision(const string& d1, const string& d1out, const string& d2, const string& d2out, const string& d3, const string& d3out, const string& d4, const string& d4out) {
    //d1 = dec1;
    if (userText == d1) {
        cout << d1out << endl;
        cin >> userText;
        cout << endl;
    } else if (userText == d2) {
        cout << d2out << endl;
        cin >> userText;
        cout << endl;
    } else if (userText == d3){
        cout << d3out << endl;
        cin >> userText;
        cout << endl;
    } else if (userText == d4){
        cout << d4out << endl;
        cin >> userText;
        cout << endl;
    }
}